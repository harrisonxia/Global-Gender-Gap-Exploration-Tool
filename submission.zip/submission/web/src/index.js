import index from './js/index'
import './index.css'

// this is the default entry point for webpack 4
