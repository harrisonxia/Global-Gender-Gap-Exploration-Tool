const merge = require('webpack-merge')

const webpackBaseConfig = require('./webpack.common.config.js')

module.exports = merge(
    webpackBaseConfig,
    {}
)